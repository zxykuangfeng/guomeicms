<?php
//后台管理语言包

return array(
	
	'_module_config_admin_log' => '配置',
	
	'_module_delete_admin_log' => '删除附件',
	
);
