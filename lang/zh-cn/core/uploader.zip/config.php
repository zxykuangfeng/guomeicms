<?php

return array(
	'uploader_config' => '上传设置',
	'test_ftp' => '测试FTP',
	'ftp_enabled' => '是否开启远程FTP附件',
	'ftp_config' => '远程FTP设置',
	'ftp_host' => 'FTP主机',
	'ftp_port' => 'FTP端口',
	'ftp_user' => 'FTP用户名',
	'ftp_password' => 'FTP密码',
	'ftp_dir' => 'FTP目录',
	'ftp_url' => 'FTP访问URL',
	
	'ftp_test_connect' => 'FTP连接状态',
	'ftp_test_connect_fail' => '连接失败',
	'ftp_test_login_fail' => '登录失败',
	'ftp_test_mkdir' => 'FTP创建目录',
	'ftp_test_delete' => 'FTP删除',
	'ftp_test_put' => 'FTP上传',
	'ftp_test_rmdir' => 'FTP删除目录',
	
	'bind_upload_domain_note' => '一般不用设置<br />可以将附件上传存放到独立服务器，不占用主站带宽（只能只能绑定与核心设置处相同域名下的二级域名 ）',
	
);
